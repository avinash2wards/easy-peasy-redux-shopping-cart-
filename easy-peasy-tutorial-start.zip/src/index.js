import React from "react";
import ReactDOM from "react-dom";
import { StoreProvider, createStore } from "easy-peasy";

import App from "./components/app";
import { storeModel } from "./model";
import "./styles.css";

const store = createStore(storeModel);

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StoreProvider store={store}>
    <App />
  </StoreProvider>,

  rootElement
);
