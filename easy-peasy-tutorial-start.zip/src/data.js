/**
 * Dummy data. We need to get this into a store!
 */

export const products = [
  { id: 1, name: 'Broccoli', price: 2.5 },
  { id: 2, name: 'Carrots', price: 4 },
];

export const basket = [2];
