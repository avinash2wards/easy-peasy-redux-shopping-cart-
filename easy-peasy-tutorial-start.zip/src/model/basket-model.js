import { action, thunk, computed } from "easy-peasy";
import { addProductToBasket } from "../services/basket-service";

const basketModel = {
  productIds: [1],
  count: computed(state => state.productIds.length),
  products: computed(
    [
      localState => localState.productIds, // stores in productIds arg
      (localState, storeState) => storeState.products.items // products arg
    ],
    (productIds, products) =>
      productIds.map(productId =>
        products.find(product => product.id === productId)
      )
  ),
  addedProduct: action((state, payload) => {
    state.productIds.push(payload);
  }),
  addProduct: thunk(async (actoins, payload) => {
    await addProductToBasket(payload);
    actoins.addedProduct(payload);
  }),
  removeProduct: action((state, payload) => {
    state.productIds.splice(payload, 1);
  })
};
export { basketModel };
