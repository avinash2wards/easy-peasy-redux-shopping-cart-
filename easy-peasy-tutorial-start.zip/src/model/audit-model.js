import { actionOn } from "easy-peasy";

const auditModel = {
  logs: [],
  onAddtoBasket: actionOn(
    // targetResolver function, resolving the addedProduct action as our target
    (localActions, storeActions) => storeActions.basket.addedProduct,

    // action handler which gets executed when our target action executes (above one)
    (localState, target) => {
      localState.logs.push(`Added product to basket: ${target.payload}`);
    }
    // receives a target obj containing the payload of the target
  )
};

export { auditModel };
