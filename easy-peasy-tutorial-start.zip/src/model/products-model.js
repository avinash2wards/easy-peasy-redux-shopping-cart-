import { computed } from "easy-peasy";

const productsModel = {
  items: [
    { id: 1, name: "Eerulli", price: 5 },
    { id: 2, name: "Moolangi", price: 2.5 }
  ],
  getById: computed(state =>
    // 👇 return a function that accepts an "id" argument
    id => state.items.map(product => product.id === id)
  )
};

export { productsModel };
